from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework import status, viewsets
from rest_framework.decorators import action
from .serializers import RegisterSerializer, UserSerializer, DocumentSerializer, ClauseSerializer, ContractProposalSerializer
from .models import Document, Clause, ContractProposal
from .services import nlp_service, mapping_service, generation_service, deployment_service
from .permissions import IsLawyer

@api_view(['GET'])
@permission_classes([AllowAny])
def health_check(request):
    return Response({"status": "healthy", "message": "Backend is operational"})

class DocumentViewSet(viewsets.ModelViewSet):
    serializer_class = DocumentSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Document.objects.filter(owner=self.request.user)

    def get_permissions(self):
        if self.action in ['create', 'destroy', 'deploy']:
            return [IsAuthenticated(), IsLawyer()]
        return super().get_permissions()

    def perform_create(self, serializer):
        document = serializer.save(owner=self.request.user)
        # Trigger NLP processing (In a real app, this should be a background task)
        nlp_service.process_document(document)

    @action(detail=True, methods=['get'])
    def clauses(self, request, pk=None):
        document = self.get_object()
        clauses = document.clauses.all()
        serializer = ClauseSerializer(clauses, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['get'])
    def raw_text(self, request, pk=None):
        document = self.get_object()
        try:
            text = nlp_service.extract_text_from_file(document.file.path)
            return Response({"text": text})
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['get', 'post'])
    def proposal(self, request, pk=None):
        document = self.get_object()
        
        if request.method == 'POST':
            # Check if user is lawyer to generate
            if request.user.role != 'LAWYER':
                return Response({"error": "Only lawyers can generate proposals."}, 
                                status=status.HTTP_403_FORBIDDEN)
            
            proposal = mapping_service.suggest_templates(document)
            if proposal:
                # Trigger code generation
                generation_service.generate_solidity_code(proposal)
            else:
                return Response({"error": "Could not generate proposal. Ensure clauses are approved."}, 
                                status=status.HTTP_400_BAD_REQUEST)
        
        try:
            proposal = document.proposal
            serializer = ContractProposalSerializer(proposal)
            return Response(serializer.data)
        except ContractProposal.DoesNotExist:
            return Response({"error": "No proposal found for this document."}, 
                            status=status.HTTP_404_NOT_FOUND)

    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated, IsLawyer])
    def deploy(self, request, pk=None):
        document = self.get_object()
        try:
            proposal = document.proposal
            if not proposal.client_approved:
                return Response({"error": "Client must approve the contract before deployment."}, 
                                status=status.HTTP_400_BAD_REQUEST)
            
            result = deployment_service.deploy_to_blockchain(proposal)
            if "error" in result:
                return Response(result, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
            return Response(result)
        except ContractProposal.DoesNotExist:
            return Response({"error": "No proposal found for this document."}, 
                            status=status.HTTP_404_NOT_FOUND)

from rest_framework.exceptions import PermissionDenied

class ClauseViewSet(viewsets.ModelViewSet):
    serializer_class = ClauseSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Clause.objects.filter(document__owner=self.request.user)

    def get_permissions(self):
        if self.action in ['update', 'partial_update', 'destroy', 'create']:
            return [IsAuthenticated(), IsLawyer()]
        return super().get_permissions()

class ContractProposalViewSet(viewsets.ModelViewSet):
    serializer_class = ContractProposalSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return ContractProposal.objects.filter(document__owner=self.request.user)

    def perform_update(self, serializer):
        # Clients can only approve, not change other fields
        if self.request.user.role == 'CLIENT':
            allowed_fields = {'client_approved'}
            sent_fields = set(self.request.data.keys())
            if not sent_fields.issubset(allowed_fields):
                 raise PermissionDenied("Clients are only authorized to update the approval status.")
        
        # Lawyers can update anything but only on their own documents (queryset handles this)
        serializer.save()

@api_view(['POST'])
@permission_classes([AllowAny])
def register_user(request):
    serializer = RegisterSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_current_user(request):
    serializer = UserSerializer(request.user)
    return Response(serializer.data)
